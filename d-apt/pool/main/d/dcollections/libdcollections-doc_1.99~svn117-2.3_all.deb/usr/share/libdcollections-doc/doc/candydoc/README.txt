This is a modified version of CandyDoc.  The changes are listed below.


2010-07-22, Lars T. Kyllingstad:
    explorer.js:229   path[i]  -->  join("_")
